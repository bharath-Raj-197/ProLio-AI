node_modules/
.env
.env.local
dist/
build/